/** Automatically generated file. DO NOT MODIFY */
package com.facebook.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}